using System.Collections.Generic;
using UnityEngine;
using Meta.XR.MRUtilityKit;

public class MRUKAnchorProvider : MonoBehaviour, IAnchorProvider
{
    public bool currentRoomOnly = true;
    public bool excludeGlobalMesh = true;

    readonly List<MRUKAnchor> _cache = new();
    bool _hooked;

    void OnEnable()
    {
        InvokeRepeating(nameof(TryHook), 0f, 0.25f);
    }

    void OnDisable()
    {
        CancelInvoke(nameof(TryHook));
        if (MRUK.Instance != null)
            MRUK.Instance.SceneLoadedEvent.RemoveListener(Refresh);
        _hooked = false;
    }

    void TryHook()
    {
        if (_hooked) { CancelInvoke(nameof(TryHook)); return; }
        if (MRUK.Instance == null) return;

        MRUK.Instance.SceneLoadedEvent.AddListener(Refresh);
        _hooked = true;
        Refresh();
        CancelInvoke(nameof(TryHook));
    }

    void Refresh()
    {
        _cache.Clear();
        if (MRUK.Instance == null || !MRUK.Instance.IsInitialized) return;

        var room = MRUK.Instance.GetCurrentRoom();
        if (room != null) _cache.AddRange(room.Anchors);

        if (excludeGlobalMesh)
            _cache.RemoveAll(a => a != null && a.Label == MRUKAnchor.SceneLabels.GLOBAL_MESH);
    }

    public List<MRUKAnchor> GetAnchors() => _cache;
}
